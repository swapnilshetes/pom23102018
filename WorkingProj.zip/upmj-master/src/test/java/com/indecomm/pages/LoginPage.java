package com.indecomm.pages;

import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LoginPage {

	// Variables
	private AppiumDriver driver;

	// Find Elements
	/*
	 * @AndroidFindBy(xpath =
	 * "//*[@content-desc=\"AEG\"]/android.widget.EditText[1]") public MobileElement
	 * txtUserName;
	 */
	/*
	 * @AndroidFindBy(xpath =
	 * "//*[@content-desc=\"AEG\"]/android.widget.EditText[2]") public MobileElement
	 * txtPassword;
	 * 
	 * @AndroidFindBy(xpath = "//android.webkit.WebView[@content-desc='AEG']")
	 * public MobileElement btnLogin;
	 */

	// Register POM class
	public LoginPage(AppiumDriver<MobileElement> driver) {
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
		System.out.println("On Login Page");
	}

	// Action methods

	// Continue button click
	public void ProcessLogin() {

		/*
		 * txtUserName.click(); driver.getKeyboard().sendKeys("abc");
		 * txtPassword.click(); driver.getKeyboard().sendKeys("abc"); btnLogin.click();
		 */

	}

}