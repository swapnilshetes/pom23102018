package com.indecomm.pages;

import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class LandingPage {

	// Variables
	private AppiumDriver driver;

	// Find Elements
	@AndroidFindBy(xpath = "//*[@content-desc='CONTINUE' and @class='android.view.View']")
	public MobileElement btnCont;

	// Register POM class
	public LandingPage(AppiumDriver<MobileElement> driver) {

		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	// Action methods

	// Continue button click
	public void NavigateToLogin() {
		btnCont.click();
		// return new LoginPage(driver);

	}

}
