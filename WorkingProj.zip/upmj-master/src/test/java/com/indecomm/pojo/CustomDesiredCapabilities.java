/**
 * 
 */
/**
 * @author navjot
Decorator/Wrapper Class by Aggregation
 *
 */
package com.indecomm.pojo;

import java.text.SimpleDateFormat;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class CustomDesiredCapabilities 
{
	DesiredCapabilities desiredCapabilities;
	String appiumServer;
	String port;
	public DesiredCapabilities getDesiredCapabilities() {
		return desiredCapabilities;
	}
	public void setDesiredCapabilities(DesiredCapabilities desiredCapabilities) {
		this.desiredCapabilities = desiredCapabilities;
	}
	
	
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getAppiumServer() {
		return appiumServer;
	}
	public void setAppiumServer(String appiumServer) {
		this.appiumServer = appiumServer;
	}
	
	public String startAppium() throws InterruptedException{
		AppiumDriverLocalService appiumService;
	    String appiumServiceUrl;
	    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		
	    System.out.println("--- Appium Initialise ---" );
		Thread.sleep(1000);
		
		appiumService=AppiumDriverLocalService.buildService( new AppiumServiceBuilder().usingPort( Integer.parseInt(this.port)));
		//appiumService = AppiumDriverLocalService.buildDefaultService();
		
		appiumService.start();
        appiumServiceUrl = appiumService.getUrl().toString();
        return appiumServiceUrl;
	}
	
	
}